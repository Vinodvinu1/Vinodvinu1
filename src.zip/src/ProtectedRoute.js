import { Navigate } from "react-router-dom";
import { useUserAuth } from "./UserAuthContext";

export const ProtectedRoute = ({ children }) => {
  const { user } = useUserAuth();
  if (user && Object.keys(user).length === 0) {
    // user is not authenticated
    return <Navigate to="/" />;
  }
  return children;
};