import logo from "./logo.svg";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import Login from "./Components/Login";
import SignUp from "./Components/SignUp";
import ForgotPassword from "./Components/ForgotPassword.js";
import { UserAuthContextProvider } from "./UserAuthContext";
import { ProtectedRoute } from "./ProtectedRoute";
import Dashboard from "./Components/Dashboard";
import Navbar from "./Components/Dashboard/Navbar";

function App() {
  return (
    <div className="App">
      <Navbar />
      <UserAuthContextProvider>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route path="/sign-up" element={<SignUp />} />
          <Route path="/forgot" element={<ForgotPassword />} />
        </Routes>
      </UserAuthContextProvider>
    </div>
  );
}

export default App;
