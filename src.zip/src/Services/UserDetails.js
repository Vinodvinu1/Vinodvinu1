import React from "react";
import {db} from "../firebase";
import {
    collection
    ,getDocs
    ,addDoc
    ,updateDoc
    ,deleteDoc
    ,doc

} from "firebase/firestore";


const addUser = async (doc)=>{
    const userDetailsCollection = collection(db, "userdetails");
    const result = await addDoc(userDetailsCollection,{...doc});
    return result;
}

const upDateUserDetails = async (id,updateUser)=>{
    const user = collection(db, "userdetails",id);
    
    const result = await updateDoc(user,updateUser);
    return result;
}
const deleteUser = async (id)=>{
    const user = collection(db, "userdetails",id);
    
    const result= await deleteDoc(user);
    return result;
}
const getAllUser = async ()=>{
    const user = collection(db,"userdetails");
    const data = await getDocs(user);
    const docs = data.docs.map((doc)=>({...doc.data(),id:doc.id}));
    // const data = await getDocs(userCollecttionRef)
    //     setUsers(data.docs.map((doc)=>({...doc.data(),id:doc.id})))
    return docs;
}
const getUser = (id)=>{
    const user = collection(db, "userdetails",id);
    
    return getUser(user);
}
export{
    addUser,
    getAllUser,
    upDateUserDetails,
    deleteUser
}