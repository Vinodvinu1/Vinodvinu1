import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { upDateUserDetails } from "../../Services/UserDetails";

function getDate() {
  const today = new Date();
  return today.toLocaleDateString() + " " + today.toLocaleTimeString();
}
export default function ModalPopup({ user, closeModal, updateUsers }) {
  const [saveEditValues, setSaveEditValues] = useState({
    id: "",
    userName: "",
    email: "",
    role: "",
    status: "",
    date: getDate(),
  });

  const navigate = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setSaveEditValues({
      ...saveEditValues,
      [name]: value,
    });
  };
  const handleSubmitEdit = async () => {
    try {
      console.log(saveEditValues);

      const response = await upDateUserDetails(
        saveEditValues.id,
        saveEditValues
      );
      // const {userName,password} = signUpForm;
      // const response = await logIn(userName,password);
      if (response) {
        console.log(response);
        closeModal();
        updateUsers(response)
        
        //navigate("/dashboard");
      }
    } catch (error) {}
    // console.log();
  };

 
  useEffect(() => {
    if(user){
        setSaveEditValues(user);
    }
    
  }, [user]);

  return (
    <div>
      <div class="modal" id="myModal" style={{ display: "block", opacity: 1 }}>
        <div class="modal-dialog modal-xg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Modal Heading</h4>
              <button
                type="button"
                class="btn-close"
                onClick={closeModal}
              ></button>
            </div>

            <div class="modal-body">
              <form>
                <div class="row">
                  <div class="col-md-6">
                    <label for="recipient-name" class="col-form-label">
                      User-ID
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="recipient-name"
                      name="id"
                      value={saveEditValues.id}
                      onChange={handleInput}
                    />
                  </div>
                  <div class="col-md-6">
                    <label for="recipient-name" class="col-form-label">
                      User Name
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="recipient-name"
                      name="userName"
                      value={saveEditValues.userName}
                      onChange={handleInput}
                    />
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <label for="recipient-name" class="col-form-label">
                      Email
                    </label>
                    <input
                      type="text"
                      class="form-control"
                      id="recipient-name"
                      name="email"
                      value={saveEditValues.email}
                      onChange={handleInput}
                    />
                  </div>
                  <div class="col-md-6">
                    <label for="recipient-name" class="col-form-label">
                      Role
                    </label>
                    <select
                      class="form-select"
                      aria-label="Default select example1"
                      name="role"
                      value={saveEditValues.role}
                      onChange={handleInput}
                    >
                      <option> Select Role</option>
                      <option value="Crew Admin">Crew Admin</option>
                      <option value="Transport Admin">Transport Admin</option>
                    </select>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <label for="recipient-name" class="col-form-label">
                        Status
                      </label>
                      <select
                        class="form-select"
                        aria-label="Default select example2"
                        name="status"
                        value={saveEditValues.status}
                        onChange={handleInput}
                      >
                        <option > Select Status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label for="recipient-name" class="col-form-label">
                        User Access Life Span
                      </label>

                      <input
                        type="Date"
                        class="form-control"
                        id="recipient-name"
                        name="date"
                        value={saveEditValues.date}
                        onChange={handleInput}
                      />
                    </div>
                  </div>
                </div>
              </form>
            </div>

            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-success "
                
                onClick={closeModal}
              >
                Cancel
              </button>
              <button
                type="button"
                class="btn btn-success "
                onClick={handleSubmitEdit}
              >
                Save Edits
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
