import React, { useEffect, useState } from "react";
//import { useNavigate } from "react-router-dom";
import { deleteUser, getAllUser } from "../../Services/UserDetails";
import ModalPopup from "./ModalPopup";
import Navbar from "./Navbar";


export default function Dashboard() {
  const [users, setUsers] = useState([]);
  const [open, setOpen] = useState(false);

  const [selected, setSelected] = useState()
 //const useNavigate = useNavigate();
  const fetchUsers = async () => {
    try {
      const response = await getAllUser();
      if (response) {
        setUsers(response);
        console.log(response);
      }
    } catch (error) {}
  };
  useEffect(() => {
    fetchUsers();
    // getAllUser();
    // console.log(docs);
  }, []);

  const handleDelete = async (id) => {
    const response = await deleteUser(id);
    if(response){
      console.log(response);
      setUsers(response)
    }
  };
  const handleEdit = (idx) => {
    setOpen(true);
    setSelected(users[idx])
    //useNavigate("/edit")
  };
  const closeModal = ()=>{
    setOpen(false);

  }
  const updateUsers = (data)=>{
    setUsers(data)

  }

  return (
    <div>
      {/* <Navbar /> */}
      <div className="container mt-5">
        <div class="input-group">
          <div class="form-outline">
           <input type="search" id="form1" class="form-control" />
           <label class="form-label" for="form1">Search</label>
         </div>
         
        </div>
        <table className="table table-borderless table-responsive card-1 p-4">
          <thead>
            <tr className="border-bottom">
              <th>
                <span className="ml-2">User ID</span>
              </th>
              <th>
                <span className="ml-2">Username</span>
              </th>
              <th>
                <span className="ml-2">Email</span>
              </th>

              <th>
                <span className="ml-2">Status</span>
              </th>
              <th>
                <span className="ml-2">Role</span>
              </th>
              <th>
                <span className="ml-4">Last Edited</span>
              </th>
              <th>
                <span className="ml-5 "></span>
              </th>
            </tr>
          </thead>
          <tbody>
            {users &&
              users.map((item, idx) => (
                <tr className="border-bottom" key={item.id}>
                  <td>
                    <div className="p-2">
                      <span className="d-block font-weight-bold">
                        {item.id}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="p-2">
                      <span className="d-block font-weight-bold">
                        {item.userName}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="p-2">
                      <span className="d-block font-weight-bold">
                        {item.email}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="p-2">
                      <span className="d-block font-weight-bold">
                        {item.status}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="p-2">
                      <span className="d-block font-weight-bold">
                        {item.role}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="p-2">
                      <span className="d-block font-weight-bold">
                        {item.date}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div className="p-2">
                      <button
                        type="button"
                        className="btn btn-primary btn-sm"
                        onClick={()=>handleEdit(idx)}
                        style={{
                          paddingLeft: "2.5rem",
                          paddingRight: "2.5rem",
                        }}
                      >
                        Edit
                      </button>

                      <button
                        type="button"
                        className="btn btn-danger btn-sm ms-3"
                        onClick={()=>handleDelete(item.id)}
                        style={{
                          paddingLeft: "2.5rem",
                          paddingRight: "2.5rem",
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            {/* <tr className="border-bottom">
              <td>
                <div className="p-2">
                  <span className="d-block font-weight-bold">Tomorrow</span>
                  <small>2:30PM</small>
                </div>
              </td>
            </tr> */}
          </tbody>
        </table>
      </div>

      {/* <!-- Modal --> */}
      {open && <ModalPopup user={selected} closeModal={closeModal} updateUsers={updateUsers} /> }
    </div>
  );
}
