import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useUserAuth } from "../../UserAuthContext";
import "./Login.css";


export default function Login() {
  const [login, setLogin] = useState({
    userName: "",
    password: "",
  });

  const { logIn } = useUserAuth();
  const navigate = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setLogin({
      ...login,
      [name]: value,
    });
  };

  const handleLogin = async () => {
    try {
      const { userName, password } = login;
      const response = await logIn(userName, password);
      if (response) {
        console.log(response);
        navigate("/dashboard", { user: response });
      }
    } catch (error) {}
    console.log(login);
  };
   

  return (
    <div className="shadow p-3 mb-5 bg-info rounded">
      <section className="vh-100  ">
        <div className="container-fluid h-custom ">
          <div className="row d-flex justify-content-center align-items-center h-100 backGroundImage">
            {/* <div className="col-md-9 col-lg-6 col-xl-5">
              <img className="img-fluid" src={land} alt="Sample image" />
            </div> */}
            <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 shadow p-3 mb-5 bg-body w-25 rounded">
              <form className="">
                <div className="form-outline mb-4">
                  <label
                    className="form-label d-flex fw-normal"
                    for="form3Example3"
                  >
                    User Name
                  </label>
                  <input
                    type="text"
                    id="form3Example3"
                    name="userName"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                    placeholder="Enter a valid email address"
                  />
                </div>

                <div className="form-outline mb-3 ">
                  <label className="form-label d-flex" for="form3Example4">
                    Password
                  </label>
                  <input
                    type="password"
                    id="form3Example4"
                    name="password"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                    placeholder="Enter password"
                  />
                </div>

                <div className="d-flex justify-content-between align-items-center">
                  <div className="form-check mb-0">
                    <input
                      className="form-check-input me-2"
                      type="checkbox"
                      value=""
                      id="form2Example3"
                    />
                    <label className="form-check-label" for="form2Example3">
                      Remember me
                    </label>
                  </div>
                  <Link to="/forgot" className="text-body">
                    Forgot password?
                  </Link>
                </div>

                <div className="text-center text-lg-start mt-4 pt-2">
                  <button
                    type="button"
                    onClick={handleLogin}
                    className="btn btn-primary btn-lg"
                    style={{ paddingLeft: "2.5rem", paddingRight: "2.5rem" }}
                  >
                    Login
                  </button>
                  <p className="small fw-bold mt-2 pt-1 mb-0">
                    Don't have an account?{" "}
                    <Link to="sign-up" className="link-danger">
                      Register
                    </Link>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
