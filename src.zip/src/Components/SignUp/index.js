import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { addUser } from "../../Services/UserDetails";
import land from "../../images/landing.jpg";

function getDate() {
  const today = new Date();
  return today.toLocaleDateString() + " " + today.toLocaleTimeString();
}

export default function SignUp() {
  const [signUpForm, setSignUpForm] = useState({
    firstName: "",
    lastName: "",
    userName: "",
    email: "",
    password: "",
    role: "N/A",
    status: "N/A",
    confirmPassword: "",
    date: getDate(),
  });

  const navigate = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setSignUpForm({
      ...signUpForm,
      [name]: value,
    });
  };

  const handleSignUp = async () => {
    try {
      const response = await addUser({ ...signUpForm });
      // const {userName,password} = signUpForm;
      // const response = await logIn(userName,password);
      if (response) {
        console.log(response);
        navigate("/");
      }
    } catch (error) {}
    // console.log();
  };
  return (
    <div>
      <section className="vh-100 bg-info p-2">
        <div className="container-fluid h-custom">
          <div className="row d-flex justify-content-center align-items-center h-100 backGroundImage">
            <div className="col-md-9 col-lg-6 col-xl-5">
              
            </div>
            <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 shadow w-25 bg-white p-1 rounded ms-2">
              <form>
                <div className="form-outline mb-4">
                  <label className="form-label d-flex" for="form3Example3">
                    First Name
                  </label>
                  <input
                    type="text"
                    id="form3Example3"
                    name="firstName"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                  />
                </div>
                <div className="form-outline mb-4">
                  <label className="form-label d-flex" for="form3Example3">
                    Last Name
                  </label>
                  <input
                    type="text"
                    id="form3Example3"
                    name="lastName"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                  />
                </div>
                <div className="form-outline mb-4">
                  <label className="form-label d-flex" for="form3Example3">
                    User Name
                  </label>
                  <input
                    type="text"
                    id="form3Example3"
                    name="userName"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                  />
                </div>
                <div className="form-outline mb-4">
                  <label className="form-label d-flex" for="form3Example3">
                    Email
                  </label>
                  <input
                    type="email"
                    id="form3Example3"
                    name="email"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                  />
                </div>
                <div className="form-outline mb-3">
                  <label className="form-label d-flex" for="form3Example4">
                    Password
                  </label>
                  <input
                    type="password"
                    id="form3Example4"
                    name="password"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                  />
                </div>
                <div className="form-outline mb-3">
                  <label className="form-label d-flex" for="form3Example4">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    id="form3Example4"
                    name="confirmPassword"
                    onChange={handleInput}
                    className="form-control form-control-lg"
                  />
                </div>
                <div className="text-center text-lg-start mt-4 pt-2 d-flex flex-row-reverse">
                  <button
                    type="button"
                    className="btn btn-primary btn-lg"
                    onClick={handleSignUp}
                    style={{ paddingLeft: "2.5rem", paddingRight: "2.5rem" }}
                  >
                    SignUp
                  </button>
                </div>
                <div className="d-flex justify-content-between align-items-center">
                  <p className="small fw-bold mt-2 pt-1 mb-0 text-body">
                    Already have an account?{" "}
                    <Link to="/" className="link-danger">
                      Login
                    </Link>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
