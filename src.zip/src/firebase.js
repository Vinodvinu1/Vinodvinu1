import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAQEIwHJRf0xU8xhQV88Sn2xXI1R9U1CFc",
  authDomain: "auth01-178ab.firebaseapp.com",
  projectId: "auth01-178ab",
  storageBucket: "auth01-178ab.appspot.com",
  messagingSenderId: "334081234455",
  appId: "1:334081234455:web:adea90cd27b41f593bae52",
  measurementId: "G-ZQ1MM5BR9S"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;
